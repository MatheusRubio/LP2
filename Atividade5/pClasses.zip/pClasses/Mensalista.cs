﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pClasses
{
    class Mensalista : Empregado //Dizer que é a "filha" da cat empregado, herdar tudo que esta publico do empregado
    {
        public double SalarioMensal { get; set; }

        //Construtor
        public Mensalista() //Nome da propria classe
        {

        }

        public Mensalista(int matx, string nomex, DateTime datax, double salariox) //Sobrecarga
        {
            Matricula = matx;
            NomeEmpregado = nomex;
            DataEntradaEmpresa = datax;
            SalarioMensal = salariox;
        }

        public override double SalarioBruto() //Sobreescreve o metodo
        {
            return SalarioMensal;
        }
    }
}

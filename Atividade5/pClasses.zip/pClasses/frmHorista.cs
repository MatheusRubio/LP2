﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pClasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnInstanciarHorista_Click(object sender, EventArgs e)
        {
            /*Não pode criar/instanciar objetos de classes abstratas: 
              Empregado objEmpregado = new Empregado();*/

            //Instanciando o objeto da classe Horista
            Horista objHorista = new Horista();

            //set
            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHoras.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFaltas.Text);

            //get
            MessageBox.Show("Nome: " + objHorista.NomeEmpregado + "\n" +
                                "Matrícula: " + objHorista.Matricula + "\n" +
                                "Tempo Trabalho (dias): " + objHorista.TempoTrabalho().ToString() + "\n" +
                                "salario: " + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pClasses
{
    abstract class Empregado
    {
        private int matricula; //Atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula //Propriedade
        {
            get { return matricula; } //usar fora
            set { matricula = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }        
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        //Métodos são ações/comportamentos
        
        public virtual/*virtual = permite a sobreecrição*/ int TempoTrabalho()
        {
            //Representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);

            return (span.Days); //Diferença em dias
        }

        public abstract double SalarioBruto();
    }
}

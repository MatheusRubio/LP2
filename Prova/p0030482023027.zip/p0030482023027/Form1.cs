﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace p0030482023027
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            lboxSaida.Items.Clear();

            double[,] vendas = new double[7, 4];
            string aux = "";
            //RA: 0030482023027

            for (int l = 0; l < vendas.GetLength(0)/*Pega nº de linhas*/; l++)
            {
                for (int c = 0; c < vendas.GetLength(1)/*Pega nº de colunas*/; c++)
                {                   
                    aux = Interaction.InputBox(String.Format("Valor da {0}ª semana,\ndo {1}º mês.", (c + 1), (l + 1)), "$ Entrada de valores monetários $");

                    if (aux == "")
                        break;
                    if (!double.TryParse(aux, out vendas[l, c]))
                    {
                        MessageBox.Show("Dado Inválido");
                        c--;
                    }
                }
            }

            double totalMes, totalGeral = 0;
            for (int l = 0; l < vendas.GetLength(0); l++)
            {
                totalMes = 0;
                lboxSaida.Items.Add("Total do mês " + Convert.ToString(l + 1));
                for (int c = 0; c < vendas.GetLength(1); c++)
                {
                    lboxSaida.Items.Add(String.Format("   •   Semana {0}: {1:C2}",(c + 1), vendas[l, c]));
                    totalMes += vendas[l, c];
                }
                lboxSaida.Items.Add(String.Format("   >> Total do mês: {0:C2}", totalMes));
                lboxSaida.Items.Add("");
                totalGeral += totalMes;
            }
            lboxSaida.Items.Add(String.Format("Total Geral: {0:C2}", totalGeral));
        }
    }
}

﻿
namespace pMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnContNumero = new System.Windows.Forms.Button();
            this.btnAchaBranco = new System.Windows.Forms.Button();
            this.btnContLetra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxtTexto
            // 
            this.rtxtTexto.Location = new System.Drawing.Point(87, 28);
            this.rtxtTexto.Name = "rtxtTexto";
            this.rtxtTexto.Size = new System.Drawing.Size(287, 136);
            this.rtxtTexto.TabIndex = 0;
            this.rtxtTexto.Text = "";
            // 
            // btnContNumero
            // 
            this.btnContNumero.Location = new System.Drawing.Point(87, 195);
            this.btnContNumero.Name = "btnContNumero";
            this.btnContNumero.Size = new System.Drawing.Size(75, 51);
            this.btnContNumero.TabIndex = 1;
            this.btnContNumero.Text = "Contar Numeros";
            this.btnContNumero.UseVisualStyleBackColor = true;
            this.btnContNumero.Click += new System.EventHandler(this.btnContNumero_Click);
            // 
            // btnAchaBranco
            // 
            this.btnAchaBranco.Location = new System.Drawing.Point(196, 195);
            this.btnAchaBranco.Name = "btnAchaBranco";
            this.btnAchaBranco.Size = new System.Drawing.Size(75, 51);
            this.btnAchaBranco.TabIndex = 2;
            this.btnAchaBranco.Text = "Primeiro Espaço em Branco";
            this.btnAchaBranco.UseVisualStyleBackColor = true;
            this.btnAchaBranco.Click += new System.EventHandler(this.btnAchaBranco_Click);
            // 
            // btnContLetra
            // 
            this.btnContLetra.Location = new System.Drawing.Point(299, 195);
            this.btnContLetra.Name = "btnContLetra";
            this.btnContLetra.Size = new System.Drawing.Size(75, 51);
            this.btnContLetra.TabIndex = 3;
            this.btnContLetra.Text = "Contar Letras";
            this.btnContLetra.UseVisualStyleBackColor = true;
            this.btnContLetra.Click += new System.EventHandler(this.btnContLetra_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContLetra);
            this.Controls.Add(this.btnAchaBranco);
            this.Controls.Add(this.btnContNumero);
            this.Controls.Add(this.rtxtTexto);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxtTexto;
        private System.Windows.Forms.Button btnContNumero;
        private System.Windows.Forms.Button btnAchaBranco;
        private System.Windows.Forms.Button btnContLetra;
    }
}
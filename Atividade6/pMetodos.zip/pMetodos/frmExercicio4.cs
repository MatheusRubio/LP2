﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContNumero_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Não pode vazio");
            else
            {
                char[] texto = rtxtTexto.Text.ToCharArray();
                int cont = 0;

                for(int i=0; i < texto.Length; i++)
                {
                    if (char.IsDigit(texto[i]))
                        cont++;
                }                
                MessageBox.Show(Convert.ToString(cont) + " número(s)" );
                
                rtxtTexto.Text = "";
            } 
        }

        private void btnAchaBranco_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Não pode vazio");
            else
            {
                int i = 0;

                while (!char.IsWhiteSpace(rtxtTexto.Text[i]))
                {
                    if (i == rtxtTexto.TextLength - 1)
                        break;
                    i++;
                }

                MessageBox.Show("Primeiro espaço vazio esta na " + i.ToString() + "ª posição");
            }
        }

        private void btnContLetra_Click(object sender, EventArgs e)
        {
            if (rtxtTexto.Text == "")
                MessageBox.Show("Não pode vazio");
            else
            {
                char[] texto = rtxtTexto.Text.ToCharArray();
                int cont = 0;

                foreach (char c in texto)
                {
                    if (char.IsLetter(c))
                        cont++;
                   //cont = isnumeric ? char.IsDigit(c) : cont++;
                }
                MessageBox.Show(Convert.ToString(cont) + " letra(s)");

                rtxtTexto.Text = "";
            }
        }
    }
}

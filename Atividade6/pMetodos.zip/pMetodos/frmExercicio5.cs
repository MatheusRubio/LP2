﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            Random sorteio = new Random();

            int n1, n2;

            if(int.TryParse(txtNumero1.Text, out n1) && int.TryParse(txtNumero2.Text, out n2))
            {
                int sorteado;
                if (n1 < n2)
                    sorteado = sorteio.Next(n1, n2);
                else
                    sorteado = sorteio.Next(n2, n1);

                MessageBox.Show(sorteado.ToString() + " é o nº sorteado!");
            }
            else
                MessageBox.Show("Deve ser número");
        }
    }
}

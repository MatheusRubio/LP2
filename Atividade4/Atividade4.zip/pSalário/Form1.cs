﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pSalário
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            double salBruto, salLiquido, descINSS, descIRPF, salFamilia;
            byte filhos;
            string stringone;

            if (txtNome.Text == String.Empty || txtNome.Text.Length < 10)
                MessageBox.Show("Nome Inválido");
            else
            {
                if (double.TryParse(txtSalario.Text, out salBruto))
                {                  
                    if (salBruto <= 800.47) //INSS
                    {
                        txtINSS.Text = "7,65%";
                        descINSS = salBruto * 0.0765;
                    }
                    else if (salBruto > 800.47 && salBruto <= 1050)
                    {
                        txtINSS.Text = "8,65%";
                        descINSS = salBruto * 0.0865;
                    }
                    else if (salBruto > 1050 && salBruto <= 1400.77)
                    {
                        txtINSS.Text = "9,00%";
                        descINSS = salBruto * 0.09;
                    }
                    else if (salBruto > 1400.77 && salBruto <= 2801.56)
                    {
                        txtINSS.Text = "11,00%";
                        descINSS = salBruto * 0.11;
                    }
                    else
                    {
                        txtINSS.Text = "R$ 308,17 (Teto)";
                        descINSS = 308.17;
                    }

                    if (salBruto <= 1257.12)//IRPF
                    { 
                        txtIRPF.Text = "Isento";
                        descIRPF = 0;
                    }
                    else if (salBruto < 1257.12 && salBruto <= 2512.08)
                    {
                        txtIRPF.Text = "15,00%";
                        descIRPF = salBruto * 0.15;
                    }
                    else
                    {
                        txtIRPF.Text = "27,50%";
                        descIRPF = salBruto * 0.275;
                    }

                    byte.TryParse(txtFilhos.Text, out filhos);

                    if (salBruto <= 435.52)//Salário família
                        salFamilia = 22.33 * filhos;            
                    else if (salBruto > 435.52 && salBruto <= 654.61)
                        salFamilia = 15.74 * filhos;
                    else
                        salFamilia = 0;

                    salLiquido = salBruto - descINSS - descIRPF + salFamilia;


                    //Exibição
                    txtSalarioFam.Text = "R$ " + salFamilia.ToString("N2");
                    
                    txtSalarioLiq.Text = "R$ " + salLiquido.ToString("N2");

                    txtDescINSS.Text = "R$ " + descINSS.ToString("N2");

                    txtDescIRPF.Text = "R$ " + descIRPF.ToString("N2");

                    if (radF.Checked)
                    {
                        stringone = "Os Descontos do salario da Sra. " + txtNome.Text + " ";
                        if (chCasado.CheckState == CheckState.Checked)
                            stringone = stringone + "que é casada ";
                        else
                            stringone = stringone + "que não é casada ";
                    }
                    else
                    {
                        stringone = "Os Descontos do salario do Sr. " + txtNome.Text + " ";
                        if (chCasado.CheckState == CheckState.Checked)
                            stringone = stringone + "que é casado ";
                        else
                            stringone = stringone + "que não é casado ";
                    }
                    if (filhos == 0)
                        stringone = stringone + "e não tem filhos, ";
                    else
                        stringone = stringone + "e que tem " + filhos.ToString() + " filho(s), ";
                    txtMenssagem.Text = stringone + "estão representados acima.";
                }
                else
                    MessageBox.Show("Salários Inválido!");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtFilhos.Items.Add("0");
            txtFilhos.Items.Add("1");
            txtFilhos.Items.Add("2");
            txtFilhos.Items.Add("3");
            txtFilhos.Items.Add("4");
            txtFilhos.Items.Add("5");

            txtFilhos.SelectedIndex = 0;
        }
    }
}

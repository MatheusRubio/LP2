﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace pVacina0030482023027
{
    public partial class frmVacina : Form
    {
        private BindingSource bsVacina = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsVacina = new DataSet();
        private DataSet dsCidade = new DataSet();
        private DataSet dsEnfermeiro = new DataSet();

        public frmVacina()
        {
            InitializeComponent();
        }

        private void frmVacina_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'lP2DataSet.CIDADE'. Você pode movê-la ou removê-la conforme necessário.
            try
            {
                Vacina Vac = new Vacina(); //Criar objeto
                dsVacina.Tables.Add(Vac.Listar());
                bsVacina.DataSource = dsVacina.Tables["Vacina"];
                bnVacina.BindingSource = bsVacina;                
                dgVacina.DataSource = bsVacina;

                txtId.DataBindings.Add("Text", bsVacina, "id_vacina");
                txtNome.DataBindings.Add("Text", bsVacina, "nome_vacina");
                txtDataNasc.DataBindings.Add("Text", bsVacina, "datanasc_vacina");
                txtEndereco.DataBindings.Add("Text", bsVacina, "end_vacina");
                mtxtCpf.DataBindings.Add("text", bsVacina, "cpf_vacina");
                mtxtRg.DataBindings.Add("text", bsVacina, "rg_vacina");
                txtDataVacina.DataBindings.Add("text", bsVacina, "data_vacina");
                cbxTipoVacina.DataBindings.Add("SelectedItem", bsVacina, "tipo_vacina");
                cbxComorbidade.DataBindings.Add("SelectedItem", bsVacina, "comorbidade_vacina");
                cbxPrioritario.DataBindings.Add("SelectedItem", bsVacina, "grupopriori_vacina");

                Cidade Cid = new Cidade(); //Objeto
                dsCidade.Tables.Add(Cid.Listar()); //Carregar nos nomes, baseado no índice.
                cbxCidade.DataSource = dsCidade.Tables["Cidade"];
                cbxCidade.DisplayMember = "nome_cidade";
                cbxCidade.ValueMember = "id_cidade";
                cbxCidade.DataBindings.Add("SelectedValue", bsVacina, "cidade_id_cidade");

                Enfermeiro Enf = new Enfermeiro(); //Objeto
                dsEnfermeiro.Tables.Add(Enf.Listar()); //Carregar nos nomes, baseado no índice.
                cbxEnfermeiro.DataSource = dsEnfermeiro.Tables["Enfermeiro"];
                cbxEnfermeiro.DisplayMember = "nome_enfermeiro";
                cbxEnfermeiro.ValueMember = "id_enfermeiro";
                cbxEnfermeiro.DataBindings.Add("SelectedValue", bsVacina, "enfermeiro_id_enfermeiro");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void toolStripButton6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            if(tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }
            bsVacina.AddNew();

            txtNome.ReadOnly = false;
            txtDataNasc.Enabled = true;
            txtEndereco.ReadOnly = false;
            cbxCidade.Enabled = true;
                cbxCidade.SelectedIndex = 0;
            mtxtCpf.Enabled = true;
            mtxtRg.Enabled = true;
            txtDataVacina.Enabled = true;
            cbxTipoVacina.Enabled = true;
                cbxTipoVacina.SelectedIndex = 0;
            cbxComorbidade.Enabled = true;
                cbxComorbidade.SelectedIndex = 0;
            cbxPrioritario.Enabled = true;
                cbxPrioritario.SelectedIndex = 0;
            cbxEnfermeiro.Enabled = true;
                cbxEnfermeiro.SelectedIndex = 0;
    
            btnNovo.Enabled = false;
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            DateTime data;

            // validar os dados
            if(txtNome.Text == "")
                MessageBox.Show("Nome inválido!");
            else if(!DateTime.TryParse(txtDataNasc.Value.ToString(), out data))
                MessageBox.Show("Data inválida!");
            else if(mtxtCpf.Text == "")
                MessageBox.Show("CPF inválido!");
            else if(mtxtRg.Text == "")
                MessageBox.Show("RG inválido!");
            else if(!DateTime.TryParse(txtDataVacina.Value.ToString(), out data))
                MessageBox.Show("Data da vacina inválida!");
            else
            {
                Vacina RegVac = new Vacina();
                RegVac.NomeVacina = txtNome.Text;
                RegVac.DataNascVacina = txtDataNasc.Value;
                RegVac.EndVacina = txtEndereco.Text;
                RegVac.CidadeIdVacina = Convert.ToInt32(cbxCidade.SelectedValue);
                RegVac.CpfVacina = mtxtCpf.Text;
                RegVac.RgVacina = mtxtRg.Text;
                RegVac.DataVacina = txtDataVacina.Value;
                RegVac.TipoVacina = Convert.ToChar(cbxTipoVacina.SelectedItem.ToString());
                RegVac.ComorbidadeVacina = Convert.ToChar(cbxComorbidade.SelectedItem.ToString());
                RegVac.GrupoPrioriVacina = Convert.ToChar(cbxPrioritario.SelectedItem.ToString());
                RegVac.EnfermeiroIdEnfermeiro = Convert.ToInt32(cbxEnfermeiro.SelectedValue);
                        
                if (bInclusao)
                {
                    if (RegVac.Salvar() > 0)
                    {
                        MessageBox.Show("Vacina adicionada com sucesso!");
                        txtNome.ReadOnly = true;
                        txtDataNasc.Enabled = false;
                        txtEndereco.ReadOnly = true;
                        cbxCidade.Enabled = false;
                        mtxtCpf.Enabled = false;
                        mtxtRg.Enabled = false;
                        txtDataVacina.Enabled = false;
                        cbxTipoVacina.Enabled = false;
                        cbxComorbidade.Enabled = false;
                        cbxPrioritario.Enabled = false;
                        cbxEnfermeiro.Enabled = false;

                        btnNovo.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;
                        bInclusao = false;

                        // recarrega o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bsVacina.DataSource = dsVacina.Tables["Vacina"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar vacina!");
                    }
                }
                else
                {
                    RegVac.IdVacina = Convert.ToInt32(txtId.Text);

                    if(RegVac.Alterar() > 0)
                    {
                        MessageBox.Show("Vacina alterada com sucesso!");

                        txtNome.ReadOnly = true;
                        txtDataNasc.Enabled = false;
                        txtEndereco.ReadOnly = true;
                        cbxCidade.Enabled = false;
                        mtxtCpf.Enabled = false;
                        mtxtRg.Enabled = false;
                        txtDataVacina.Enabled = false;
                        cbxTipoVacina.Enabled = false;
                        cbxComorbidade.Enabled = false;
                        cbxPrioritario.Enabled = false;
                        cbxEnfermeiro.Enabled = false;

                        btnNovo.Enabled = true;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        // recarrega o grid
                        dsVacina.Tables.Clear();
                        dsVacina.Tables.Add(RegVac.Listar());
                        bsVacina.DataSource = dsVacina.Tables["Vacina"];
                    }
                    else
                    {
                        MessageBox.Show("Erro ao alterar vacina!");
                    }
                }
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }

            txtNome.ReadOnly = false;
            txtDataNasc.Enabled = true;
            txtEndereco.ReadOnly = false;
            cbxCidade.Enabled = true;
            mtxtCpf.Enabled = true;
            mtxtRg.Enabled = true;
            txtDataVacina.Enabled = true;
            cbxTipoVacina.Enabled = true;
            cbxComorbidade.Enabled = true;
            cbxPrioritario.Enabled = true;
            cbxEnfermeiro.Enabled = true;

            btnNovo.Enabled = false;
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
            bInclusao = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            if (tbVacina.SelectedIndex == 0)
            {
                tbVacina.SelectTab(1);
            }

            if (MessageBox.Show("Confirma exclusão?", "Sim or Não", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Vacina RegVac = new Vacina();
                RegVac.IdVacina = Convert.ToInt32(txtId.Text);
                if (RegVac.Excluir() > 0)
                {
                    MessageBox.Show("Vacina excluída com sucesso!");

                    // recarrega o grid
                    dsVacina.Tables.Clear();
                    dsVacina.Tables.Add(RegVac.Listar());
                    bsVacina.DataSource = dsVacina.Tables["Vacina"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir vacina!");
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            bsVacina.CancelEdit();

            txtNome.ReadOnly = false;
            txtDataNasc.Enabled = true;
            txtEndereco.ReadOnly = false;
            cbxCidade.Enabled = true;
            mtxtCpf.Enabled = true;
            mtxtRg.Enabled = true;
            txtDataVacina.Enabled = true;
            cbxTipoVacina.Enabled = true;
            cbxComorbidade.Enabled = true;
            cbxPrioritario.Enabled = true;
            cbxEnfermeiro.Enabled = true;

            btnNovo.Enabled = true;
            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }
    }
}

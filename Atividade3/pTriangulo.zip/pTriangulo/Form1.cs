﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtA.Text, out ladoA) && double.TryParse(txtB.Text, out ladoB) && double.TryParse(txtC.Text, out ladoC))//Valida se é número
            {
                if (ladoA > 0 && ladoB > 0 && ladoC > 0) //Valida o zero
                {

                    if (Math.Abs(ladoB - ladoC) < ladoA && ladoA < (ladoB + ladoC) &&
                        Math.Abs(ladoA - ladoC) < ladoB && ladoB < (ladoA + ladoC) &&
                        Math.Abs(ladoA - ladoB) < ladoC && ladoC < (ladoA + ladoB)) //Valida a regra do triangulo
                    {
                        if (ladoA == ladoB && ladoB == ladoC)
                            MessageBox.Show("Triângulo Equilátero!");                        
                        else if(ladoA != ladoB && ladoB != ladoC && ladoC != ladoA)
                            MessageBox.Show("Triângulo Escaleno!");
                        /*else if (ladoA != ladoB && ladoB != ladoC || (ladoB == ladoC && ladoC != ladoA) || (ladoC == ladoA && ladoA != ladoB))
                            MessageBox.Show("Triângulo Isósceles!");*/
                        else
                            MessageBox.Show("Triângulo Isósceles!");

                    }

                    else
                        MessageBox.Show("Não contempla as regras dos triângulos!");

                }
                else
                    MessageBox.Show("Lados devem ser maior que zero!");

            }
            else
                MessageBox.Show("Número(s) Inválido(s)!");

        }
    }
}

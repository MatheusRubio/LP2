﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pPesoIdeal
{
    public partial class Form1 : Form
    {
        double altura, peso, pesoIdeal;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtAltura.Text, out altura) && double.TryParse(txtPeso.Text, out peso))
            {
                if (radioM.Checked) //Condição do sexo
                    pesoIdeal = (72.7 * altura) - 58;
                else
                    pesoIdeal = (62.1 * altura) - 44.7;
                
                pesoIdeal = Math.Round(pesoIdeal, 2);

                if (peso > pesoIdeal) //Consição do peso
                    MessageBox.Show("Peso Ideal : " + pesoIdeal + "\n" + "Regime Obrigatório");
                else if (peso < pesoIdeal)
                    MessageBox.Show("Peso Ideal: " + pesoIdeal + "\n" + "Coma bastante massas ou doces");
                else
                    MessageBox.Show("Peso Ideal : " + pesoIdeal + "\n" + "Você está com o peso ideal");
                
            }
            else 
                MessageBox.Show("Peso ou altura inválidos");
        }
    }
}
